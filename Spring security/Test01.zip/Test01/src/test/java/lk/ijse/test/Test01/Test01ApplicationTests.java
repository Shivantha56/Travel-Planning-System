package lk.ijse.test.Test01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
